const express = require('express');
const router = express.Router();
const { getPostByName } = require('../controllers/user.controller');

router.use(express.json());
// router.get('/:userId/posts', getPostByName);
router.get('/:firstName/posts', getPostByName);
module.exports = router;