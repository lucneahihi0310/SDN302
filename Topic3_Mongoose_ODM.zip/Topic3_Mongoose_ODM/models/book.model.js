const mongoose = require('mongoose');
//định nghĩa lược đồ dữ liệu cho document book
const bookSchema = new mongoose.Schema({

    title: {
        type: String,
        required: [true,'Tên sách không được để trống!'],
        min: [10, 'Minimum length of title is 10 characters!'],
        max: [50, 'Maximum length of title is 50 characters!']
    },

    authors: {
        type: [],
    },
    publicationYear: {
        type: Number
    },
    genre: {
        type: String
    }
});

// tạo model book từ lược đồ bookSchema
const Book = mongoose.model('books', bookSchema);

module.exports = Book;
